setwd("C:\\Users\\HKCS\\Desktop\\Y2S1\\P S\\Labs\\IT24102353 Lab09")

y<-rnorm(25,mean=45,sd=2)

t.test(y,mu=46,alternative ="less")