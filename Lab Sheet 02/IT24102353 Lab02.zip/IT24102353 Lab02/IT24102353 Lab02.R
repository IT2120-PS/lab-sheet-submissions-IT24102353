setwd("C:\\Users\\HKCS\\Desktop\\Y2S1\\P S\\Labs\\IT24102353 Lab02")


sum((1:15) %% 3 == 0)


v <- c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
max_index <- 1

for (i in 2:length(v)) {
  if (v[i] > v[max_index]) {
    max_index <- i
  }
}

max_index






which.max(v)
