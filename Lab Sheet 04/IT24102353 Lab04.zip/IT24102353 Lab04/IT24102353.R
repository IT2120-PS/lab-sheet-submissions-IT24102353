setwd("C:\\Users\\HKCS\\Desktop\\Y2S1\\P S\\Labs\\IT24102353 Lab04")
#1
branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")
attach(branch_data)

#2
str(branch_data)

#3
boxplot(Sales_X1, main="Boxplot for Sales", horizontal=TRUE)

#4
summary(Advertising_X2)
IQR(Advertising_X2)

#5
detect_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  outliers <- sort(z[z < lb | z > ub])
  return(outliers)
}

detect_outliers(Years_X3)
