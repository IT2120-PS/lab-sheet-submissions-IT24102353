setwd("C:\\Users\\HKCS\\Desktop\\Y2S1\\P S\\Labs\\IT24102353 Lab10")

observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)
